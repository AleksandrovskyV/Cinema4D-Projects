# ARND_STRING_ATR_EXT_1.c4d
Extended Workflow for Arnold String Attribute in Cinema 4D

Based on this method (https://www.youtube.com/watch?v=EAzoIx2vrm0)
This setup automates texture path assignment for Arnold in Cinema 4D, 
designed to streamline workflows with Substance Painter and batch texture assets.

---

### Key Features
-  Randomizes Arnold textures from a selected folder  
-  Allows manual selection of a specific texture via index  
-  Uses String-type User Data for dynamic path control  
-  Clean Xpresso-based logic, easy to extend

---

### How to Set Up
1. Create a new object  
2. Go to:  
   `User Data > Add User Data > Load Preset (ARND_STRING_ATR) > OK`  
3. Copy the yellow Xpresso tag from the provided example object  
4. Make sure your textures are named numerically (e.g. `BaseColor_01.jpg`, `BaseColor_02.jpg`)

Tip: Use Adobe Bridge or similar tools for batch renaming.

---

### Example Use Cases
- Random texture assignment for multiple clones or assets  
- Quick material variations without duplicating shaders  
- Ideal for look-dev and asset iteration workflows



> Assembled by Aleksandrovsky, with assistance from GPT.  
> Feel free to fork, break, or improve this setup 
