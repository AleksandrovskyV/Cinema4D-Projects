# ARND_STRING_ATR_EXT_1.c4d

Extend workflow with Arnold String Attribute // Based from [this method](https://www.youtube.com/watch?v=EAzoIx2vrm0)
![preview](../!ALL-PREVIEW/Arnold_String-Path_Randomizer_Selector.gif)

Key Features 
